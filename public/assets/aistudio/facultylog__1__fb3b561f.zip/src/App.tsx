import React, { useState, useEffect } from 'react';
import { Sidebar, PageId } from './components/Sidebar';
import { Header } from './components/Header';
import { FacultyProfileView } from './components/FacultyProfileView';
import { DashboardView } from './components/DashboardView';
import { StudentsView } from './components/StudentsView';
import { DailyAttendanceView } from './components/DailyAttendanceView';
import { SubjectsView } from './components/SubjectsView';
import { TimetableView } from './components/TimetableView';
import { MonthlyReportView } from './components/MonthlyReportView';
import { StudentReportView } from './components/StudentReportView';
import { HolidaysView } from './components/HolidaysView';
import { BulkImportView } from './components/BulkImportView';
import { ExportReportsView } from './components/ExportReportsView';
import { SettingsView } from './components/SettingsView';
import { StepAttendanceWorkflowView } from './components/StepAttendanceWorkflowView';
import {
  DashboardStats,
  DatasetInfo,
  Student,
  Subject,
  TimetableEntry,
  Holiday
} from './types';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageId>('dashboard');
  const [datasets, setDatasets] = useState<DatasetInfo[]>([]);
  const [activeDataset, setActiveDataset] = useState<string>('Class 1');
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [students, setStudents] = useState<Student[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [timetableRows, setTimetableRows] = useState<TimetableEntry[]>([]);
  const [timetableGrid, setTimetableGrid] = useState<Record<number, Record<number, any>>>({});
  const [holidays, setHolidays] = useState<Holiday[]>([]);
  const [loading, setLoading] = useState(true);

  // Load datasets
  const fetchDatasets = async () => {
    try {
      const res = await fetch('/api/datasets');
      const data = await res.json();
      if (res.ok) {
        setDatasets(data.datasets || []);
        if (data.activeDataset) {
          setActiveDataset(data.activeDataset);
        }
      }
    } catch (err) {
      console.error('Failed to fetch datasets:', err);
    }
  };

  // Load active dataset data
  const fetchDatasetData = async () => {
    try {
      const [statsRes, studentsRes, subjectsRes, timetableRes, holidaysRes] = await Promise.all([
        fetch('/api/stats'),
        fetch('/api/students'),
        fetch('/api/subjects'),
        fetch('/api/timetable'),
        fetch('/api/holidays')
      ]);

      if (statsRes.ok) setStats(await statsRes.json());
      if (studentsRes.ok) {
        const sData = await studentsRes.json();
        setStudents(sData.students || []);
      }
      if (subjectsRes.ok) {
        const subjData = await subjectsRes.json();
        setSubjects(subjData.subjects || []);
      }
      if (timetableRes.ok) {
        const ttData = await timetableRes.json();
        setTimetableRows(ttData.rows || []);
        setTimetableGrid(ttData.grid || {});
      }
      if (holidaysRes.ok) {
        const hData = await holidaysRes.json();
        setHolidays(hData.holidays || []);
      }
    } catch (err) {
      console.error('Failed to load dataset details:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDatasets();
  }, []);

  useEffect(() => {
    fetchDatasetData();
  }, [activeDataset]);

  // Dataset Actions
  const handleSelectDataset = async (name: string) => {
    try {
      const res = await fetch('/api/datasets/active', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name })
      });
      if (res.ok) {
        setActiveDataset(name);
        fetchDatasets();
      }
    } catch (err) {
      console.error('Failed to switch dataset:', err);
    }
  };

  const handleCreateDataset = async (
    name: string,
    courseType: 'classroom' | 'lab',
    facultyName: string,
    subject: string,
    totalHours: number
  ) => {
    const res = await fetch('/api/datasets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, courseType, facultyName, subject, totalHours })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to create dataset');
    setActiveDataset(data.name);
    fetchDatasets();
  };

  const handleDeleteDataset = async (name: string) => {
    const res = await fetch(`/api/datasets/${encodeURIComponent(name)}`, {
      method: 'DELETE'
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to delete dataset');
    setActiveDataset(data.activeDataset);
    fetchDatasets();
  };

  // Student Actions
  const handleAddStudent = async (regNo: string, rollNo: string, name: string) => {
    const res = await fetch('/api/students', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reg_no: regNo, roll_no: rollNo, name })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to add student');
    fetchDatasetData();
  };

  const handleUpdateStudent = async (
    id: number,
    regNo: string,
    rollNo: string,
    name: string,
    isActive: boolean
  ) => {
    const res = await fetch(`/api/students/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reg_no: regNo, roll_no: rollNo, name, is_active: isActive })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update student');
    fetchDatasetData();
  };

  const handleDeleteStudent = async (id: number) => {
    const res = await fetch(`/api/students/${id}`, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to delete student');
    fetchDatasetData();
  };

  const handleImportStudents = async (rows: any[]) => {
    const res = await fetch('/api/students/import', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rows })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Import failed');
    fetchDatasetData();
    return data;
  };

  // Subject Actions
  const handleAddSubject = async (subj: Partial<Subject>) => {
    const res = await fetch('/api/subjects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(subj)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to add subject');
    fetchDatasetData();
  };

  const handleUpdateSubject = async (id: number, subj: Partial<Subject>) => {
    const res = await fetch(`/api/subjects/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(subj)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update subject');
    fetchDatasetData();
  };

  const handleDeleteSubject = async (id: number) => {
    const res = await fetch(`/api/subjects/${id}`, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to delete subject');
    fetchDatasetData();
  };

  // Timetable Actions
  const handleSetTimetableEntry = async (
    subjectId: number,
    weekday: number,
    periodNo: number,
    className: string
  ) => {
    const res = await fetch('/api/timetable', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        subject_id: subjectId,
        weekday,
        period_no: periodNo,
        class_name: className
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to set timetable slot');
    fetchDatasetData();
  };

  const handleClearSlot = async (weekday: number, periodNo: number, className: string) => {
    const res = await fetch('/api/timetable/slot', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ weekday, period_no: periodNo, class_name: className })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to clear slot');
    fetchDatasetData();
  };

  // Holiday Actions
  const handleAddHoliday = async (date: string, description: string, replace: boolean) => {
    const res = await fetch('/api/holidays', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ holiday_date: date, description, replace_attendance: replace })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to declare holiday');
    fetchDatasetData();
  };

  const handleDeleteHoliday = async (date: string) => {
    const res = await fetch(`/api/holidays/${date}`, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to delete holiday');
    fetchDatasetData();
  };

  // Page Title Mapping
  const pageDetails: Record<PageId, { title: string; desc: string }> = {
    dashboard: {
      title: 'Institutional Dashboard',
      desc: 'Overall attendance overview, monthly trend, and active class directory'
    },
    'attendance-workflow': {
      title: 'Step-by-Step Attendance Workflow',
      desc: 'Complete 3-step setup: Course Details & Students, Class Schedule, and Full Attendance Sheet'
    },
    'faculty-profile': {
      title: 'Faculty Profile & Configuration',
      desc: 'Configure faculty details, department, academic year, and subject hours'
    },
    students: {
      title: 'Student Management',
      desc: 'Manage student information, registration details, and class records'
    },
    'daily-attendance': {
      title: 'Daily Attendance Register',
      desc: 'Mark daily attendance with timetable periods, absent roll numbers, and live preview'
    },
    subjects: {
      title: 'Subject-Wise Semester Hours',
      desc: 'Configurable semester hours, weekly target periods, and syllabus completion'
    },
    timetable: {
      title: 'Weekly 8-Period Timetable',
      desc: 'Assign and manage period slots (P1 to P8) across weekdays with conflict prevention'
    },
    'monthly-report': {
      title: 'Monthly Attendance Report',
      desc: 'View class attendance trends, day-wise matrix, and monthly student performance'
    },
    'student-report': {
      title: 'Individual Student Report',
      desc: 'Individual transcript, attendance percentage, and official marks calculation'
    },
    holidays: {
      title: 'College Holidays Calendar',
      desc: 'Manage official holidays and ensure automatic exclusion from working days'
    },
    'bulk-import': {
      title: 'Bulk Attendance Import',
      desc: 'Upload multi-date attendance spreadsheets and matrices with instant validation'
    },
    export: {
      title: 'Export Reports & Workbooks',
      desc: 'Download authentic official Microsoft Excel attendance registers and CSV data'
    },
    settings: {
      title: 'System Settings',
      desc: 'Configure attendance threshold, department metadata, and manage class datasets'
    }
  };

  const currentMeta = pageDetails[currentPage] || pageDetails.dashboard;

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#F1F0EB] text-[#1E1E16] font-sans">
      {/* 1. Left Vertical Sidebar */}
      <Sidebar
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        activeDataset={activeDataset}
      />

      {/* 2. Main Content Viewport */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Top Header */}
        <Header
          pageTitle={currentMeta.title}
          pageDescription={currentMeta.desc}
          datasets={datasets}
          activeDataset={activeDataset}
          onSelectDataset={handleSelectDataset}
          onCreateDataset={handleCreateDataset}
          facultyName={stats?.faculty || ''}
          department={stats?.department || stats?.classHandled || ''}
          academicYear={stats?.academicYear}
          semester={stats?.semester}
          isConfigured={stats?.hasProfile}
          onOpenProfile={() => setCurrentPage('faculty-profile')}
        />

        {/* Scrollable View Area */}
        <main className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="max-w-7xl mx-auto">
            {currentPage === 'dashboard' && (
              <DashboardView
                stats={stats}
                datasets={datasets}
                onNavigate={setCurrentPage}
                onSelectDataset={handleSelectDataset}
              />
            )}

            {currentPage === 'attendance-workflow' && (
              <StepAttendanceWorkflowView
                activeDataset={activeDataset}
                datasets={datasets}
                students={students}
                onRefresh={() => {
                  fetchDatasets();
                  fetchDatasetData();
                }}
                onSelectDataset={handleSelectDataset}
                onNavigateToExport={() => setCurrentPage('export')}
              />
            )}

            {currentPage === 'faculty-profile' && (
              <FacultyProfileView
                activeDataset={activeDataset}
                onProfileUpdated={fetchDatasetData}
              />
            )}

            {currentPage === 'students' && (
              <StudentsView
                students={students}
                onRefresh={fetchDatasetData}
                onAddStudent={handleAddStudent}
                onUpdateStudent={handleUpdateStudent}
                onDeleteStudent={handleDeleteStudent}
                onImportStudents={handleImportStudents}
              />
            )}

            {currentPage === 'daily-attendance' && (
              <DailyAttendanceView
                activeDataset={activeDataset}
              />
            )}

            {currentPage === 'subjects' && (
              <SubjectsView
                subjects={subjects}
                activeDataset={activeDataset}
                onRefresh={fetchDatasetData}
                onAddSubject={handleAddSubject}
                onUpdateSubject={handleUpdateSubject}
                onDeleteSubject={handleDeleteSubject}
              />
            )}

            {currentPage === 'timetable' && (
              <TimetableView
                timetableRows={timetableRows}
                timetableGrid={timetableGrid}
                subjects={subjects}
                activeDataset={activeDataset}
                onRefresh={fetchDatasetData}
                onSetTimetableEntry={handleSetTimetableEntry}
                onClearSlot={handleClearSlot}
              />
            )}

            {currentPage === 'monthly-report' && (
              <MonthlyReportView
                activeDataset={activeDataset}
              />
            )}

            {currentPage === 'student-report' && (
              <StudentReportView
                students={students}
                activeDataset={activeDataset}
              />
            )}

            {currentPage === 'holidays' && (
              <HolidaysView
                holidays={holidays}
                onRefresh={fetchDatasetData}
                onAddHoliday={handleAddHoliday}
                onDeleteHoliday={handleDeleteHoliday}
              />
            )}

            {currentPage === 'bulk-import' && (
              <BulkImportView
                students={students}
                activeDataset={activeDataset}
                onRefresh={fetchDatasetData}
              />
            )}

            {currentPage === 'export' && (
              <ExportReportsView
                datasets={datasets}
                activeDataset={activeDataset}
              />
            )}

            {currentPage === 'settings' && (
              <SettingsView
                datasets={datasets}
                activeDataset={activeDataset}
                onRefresh={fetchDatasetData}
                onDeleteDataset={handleDeleteDataset}
              />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
